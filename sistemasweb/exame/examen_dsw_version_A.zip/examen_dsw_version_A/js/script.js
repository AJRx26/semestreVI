// ==========================================
// EXAMEN PRÁCTICO - UVStream
// Completa las etapas solicitadas en el enunciado.
// ==========================================

const mensajeDinamico = document.getElementById("mensaje-dinamico");
const contenedorDinamico = document.getElementById("contenedor-dinamico");
const listaEstrenos = document.getElementById("lista-estrenos");
const panelEstadisticas = document.getElementById("panel-estadisticas");

const formulario = document.getElementById("formulario-suscripcion");
const campoNombre = document.getElementById("nombre");
const campoCorreo = document.getElementById("correo");
const campoPlan = document.getElementById("plan");
const inputArchivo = document.getElementById("archivo-comprobante");
const zonaArrastre = document.getElementById("zona-arrastre");
const archivoSeleccionado = document.getElementById("archivo-seleccionado");
const mensajeFormulario = document.getElementById("mensaje-formulario");
const salidaJson = document.getElementById("salida-json");

let archivoActual = null;

// --------------------------------------------------
// JavaScript y DOM
// Cambiar el mensaje al cargar la página
// Ejemplo esperado: "Plataforma cargada correctamente"
// --------------------------------------------------
// mensajeDinamico.textContent = "...";

// Crear dinámicamente un nuevo bloque dentro de #contenedor-dinamico

// Asociar eventos al botón #btn-eliminar-categoria
// Eliminar una tarjeta de categoría


// --------------------------------------------------
// Formulario + comprobante de pago
// --------------------------------------------------
const mostrarArchivo = (archivo) => {
  archivoSeleccionado.textContent = "Archivo seleccionado: " + archivo.name;
  archivoSeleccionado.style.color = "#18529D";
};

zonaArrastre.addEventListener("click", () => {
  inputArchivo.click();
});

zonaArrastre.addEventListener("keydown", (event) => {
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    inputArchivo.click();
  }
});

inputArchivo.addEventListener("change", () => {
  // TODO: manejar selección de archivo y usar try/catch
});

zonaArrastre.addEventListener("dragover", (event) => {
  event.preventDefault();
  zonaArrastre.classList.add("activa");
});

zonaArrastre.addEventListener("dragleave", () => {
  zonaArrastre.classList.remove("activa");
});

zonaArrastre.addEventListener("drop", (event) => {
  event.preventDefault();
  zonaArrastre.classList.remove("activa");
  // TODO: recuperar archivo soltado y mostrarlo
});

formulario.addEventListener("reset", () => {
  archivoActual = null;
  archivoSeleccionado.textContent = "Ningún archivo seleccionado.";
  archivoSeleccionado.style.color = "";
  mensajeFormulario.textContent = "";
  salidaJson.textContent = "";
});

formulario.addEventListener("submit", (event) => {
  event.preventDefault();

  // Validar:
  // 1. nombre no vacío
  // 2. correo válido
  // 3. selección obligatoria
  // 4. archivo obligatorio
  // 5. mostrar errores en rojo y éxito en verde

  //Construir un objeto JS y convertirlo con JSON.stringify()
  //Mostrar el resultado en #salida-json
});

// --------------------------------------------------
// AJAX + JSON
// --------------------------------------------------
const cargarEstrenos = () => {
  // Usar fetch("datos/estrenos.json")
  // Insertar tarjetas o artículos en #lista-estrenos
  // Usar .catch(...)
};

const cargarEstadisticas = () => {
  //Usar fetch("datos/estadisticas.json")
  //Insertar tarjetas en #panel-estadisticas
  //Usar .catch(...)
};

//Llamar a cargarEstrenos() y cargarEstadisticas()
