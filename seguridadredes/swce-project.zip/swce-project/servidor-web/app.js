/**
 * app.js
 *
 * Punto de entrada del Servidor Web SWCE.
 *
 * Decisiones de seguridad relevantes para la documentación del proyecto:
 *
 *  - helmet(): agrega cabeceras HTTP de seguridad (X-Content-Type-Options,
 *    X-Frame-Options, Strict-Transport-Security, etc.) para mitigar
 *    ataques comunes (clickjacking, sniffing de MIME, etc.)
 *
 *  - express-session + express-mysql-session: las sesiones NO se
 *    guardan en memoria (eso no escala y se pierde si el proceso
 *    se reinicia), se guardan en la misma BD remota, en una tabla
 *    dedicada de sesiones. Esto también es necesario si en algún
 *    momento se balancea el SWCE entre más de un servidor web.
 *
 *  - Cookie de sesión: httpOnly (no accesible desde JavaScript en el
 *    navegador, mitiga robo de sesión vía XSS), sameSite 'strict'
 *    (mitiga CSRF) y secure=true en producción (la cookie solo viaja
 *    sobre HTTPS, cumpliendo el requisito de "canal seguro" del
 *    proyecto para el acceso desde Internet).
 *
 *  - El servidor web escucha en HTTPS (ver certificados en /certs)
 *    para satisfacer la política: "acceso desde Internet... a
 *    través de un canal seguro".
 */

require('dotenv').config();
const fs = require('fs');
const https = require('https');
const http = require('http');
const path = require('path');

const express = require('express');
const helmet = require('helmet');
const session = require('express-session');
const MySQLStore = require('express-mysql-session')(session);

const swceRoutes = require('./routes/swceRoutes');
const authRoutes = require('./routes/authRoutes');

const app = express();

// --- Seguridad de cabeceras HTTP ---
app.use(helmet());

// --- Parseo de formularios y JSON ---
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// --- Vistas y archivos estáticos ---
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

// --- Almacenamiento de sesiones en la BD remota ---
const sessionStore = new MySQLStore({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

app.use(session({
    key: 'swce_session_id',
    secret: process.env.SESSION_SECRET,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        sameSite: 'strict',
        secure: process.env.NODE_ENV === 'production', // true exige HTTPS real
        maxAge: 1000 * 60 * 60 * 2, // 2 horas de sesión
    },
}));

// --- Rutas ---
app.use('/', swceRoutes);
app.use('/', authRoutes);

// --- Manejo de errores 404 ---
app.use((req, res) => {
    res.status(404).render('error', { mensaje: 'Página no encontrada.' });
});

const PORT = process.env.PORT || 3000;
const USAR_HTTPS = process.env.NODE_ENV === 'production';

if (USAR_HTTPS) {
    // En producción: servir bajo HTTPS con certificado real
    // (institucional o Let's Encrypt). Coloca tus archivos en ./certs
    const opcionesSSL = {
        key: fs.readFileSync(path.join(__dirname, 'certs', 'privkey.pem')),
        cert: fs.readFileSync(path.join(__dirname, 'certs', 'fullchain.pem')),
    };
    https.createServer(opcionesSSL, app).listen(PORT, () => {
        console.log(`[SWCE] Servidor HTTPS escuchando en el puerto ${PORT}`);
    });
} else {
    // En desarrollo/demo local sin certificado: HTTP simple.
    http.createServer(app).listen(PORT, () => {
        console.log(`[SWCE] Servidor HTTP (modo desarrollo) escuchando en el puerto ${PORT}`);
        console.log('[SWCE] Para producción/demo final, configura NODE_ENV=production y certificados en ./certs');
    });
}
