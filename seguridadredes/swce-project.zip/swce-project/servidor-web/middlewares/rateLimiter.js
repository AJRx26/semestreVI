/**
 * middlewares/rateLimiter.js
 *
 * Limita el número de intentos de login por IP en una ventana de
 * tiempo. Esta es una segunda capa de defensa contra fuerza bruta,
 * independiente del bloqueo por cuenta que se hace a nivel de
 * usuario en la base de datos (intentos_fallidos / bloqueado_hasta).
 *
 * Por qué dos capas:
 *  - El límite por cuenta evita que ataquen UNA matrícula específica.
 *  - El límite por IP evita que un mismo origen pruebe muchas
 *    matrículas distintas (ataque de "credential stuffing").
 */

const rateLimit = require('express-rate-limit');

const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // ventana de 15 minutos
    max: 15, // máximo de intentos de login por IP en esa ventana
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Demasiados intentos de inicio de sesión desde esta red. Intenta más tarde.' },
});

module.exports = { loginLimiter };
