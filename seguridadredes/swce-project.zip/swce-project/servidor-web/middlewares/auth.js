/**
 * middlewares/auth.js
 *
 * Middlewares de control de acceso:
 *  - requireAuth: exige una sesión activa (usuario ha iniciado sesión).
 *  - requireRole: exige además que el usuario tenga uno de los roles
 *    permitidos (control de acceso basado en roles).
 */

function requireAuth(req, res, next) {
    if (req.session && req.session.usuario) {
        return next();
    }
    // Si la petición espera JSON (API/fetch), respondemos 401.
    if (req.headers.accept && req.headers.accept.includes('application/json')) {
        return res.status(401).json({ error: 'Sesión no iniciada o expirada.' });
    }
    return res.redirect('/login');
}

function requireRole(...rolesPermitidos) {
    return (req, res, next) => {
        if (!req.session || !req.session.usuario) {
            return res.redirect('/login');
        }
        if (!rolesPermitidos.includes(req.session.usuario.rol)) {
            return res.status(403).render('error', {
                mensaje: 'No tienes permisos para acceder a este recurso.',
            });
        }
        return next();
    };
}

module.exports = { requireAuth, requireRole };
