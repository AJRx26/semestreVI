/**
 * models/Usuario.js
 *
 * Capa de acceso a datos para usuarios. Todas las consultas usan
 * placeholders (?) en lugar de concatenar texto, para evitar
 * inyección SQL.
 */

const pool = require('../config/db');

const Usuario = {
    /**
     * Busca un usuario por su matrícula (identificador de login).
     */
    async buscarPorMatricula(matricula) {
        const [rows] = await pool.query(
            `SELECT u.id_usuario, u.matricula, u.nombre_completo, u.correo,
                    u.password_hash, u.campus, u.intentos_fallidos,
                    u.bloqueado_hasta, u.activo, r.nombre_rol
             FROM usuarios u
             JOIN roles r ON u.id_rol = r.id_rol
             WHERE u.matricula = ?`,
            [matricula]
        );
        return rows[0] || null;
    },

    async buscarPorId(idUsuario) {
        const [rows] = await pool.query(
            `SELECT u.id_usuario, u.matricula, u.nombre_completo, u.correo,
                    u.campus, r.nombre_rol
             FROM usuarios u
             JOIN roles r ON u.id_rol = r.id_rol
             WHERE u.id_usuario = ?`,
            [idUsuario]
        );
        return rows[0] || null;
    },

    async incrementarIntentosFallidos(idUsuario) {
        await pool.query(
            `UPDATE usuarios SET intentos_fallidos = intentos_fallidos + 1 WHERE id_usuario = ?`,
            [idUsuario]
        );
    },

    async resetearIntentosFallidos(idUsuario) {
        await pool.query(
            `UPDATE usuarios
             SET intentos_fallidos = 0, bloqueado_hasta = NULL, ultimo_acceso = NOW()
             WHERE id_usuario = ?`,
            [idUsuario]
        );
    },

    async bloquearTemporalmente(idUsuario, minutos) {
        await pool.query(
            `UPDATE usuarios SET bloqueado_hasta = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id_usuario = ?`,
            [minutos, idUsuario]
        );
    },

    async registrarBitacora({ idUsuario, matriculaIntento, ip, resultado }) {
        await pool.query(
            `INSERT INTO bitacora_accesos (id_usuario, matricula_intento, ip_origen, resultado)
             VALUES (?, ?, ?, ?)`,
            [idUsuario || null, matriculaIntento, ip, resultado]
        );
    },

    async crear({ matricula, nombreCompleto, correo, passwordHash, idRol, campus }) {
        const [result] = await pool.query(
            `INSERT INTO usuarios (matricula, nombre_completo, correo, password_hash, id_rol, campus)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [matricula, nombreCompleto, correo, passwordHash, idRol, campus]
        );
        return result.insertId;
    },
};

module.exports = Usuario;
