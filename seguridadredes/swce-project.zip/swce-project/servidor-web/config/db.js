/**
 * config/db.js
 *
 * Configura el pool de conexiones hacia el SERVIDOR DE BASE DE DATOS
 * remoto (VM2). Este servidor web (VM1) es el ÚNICO punto autorizado
 * para hablar con la BD, según la política de aislamiento del
 * proyecto. La BD no debe ser alcanzable desde Internet ni desde
 * otros campus directamente; solo desde la IP de este servidor.
 *
 * Se usa un pool (no conexiones sueltas) para:
 *  - Reutilizar conexiones y soportar concurrencia real de usuarios.
 *  - Evitar fugas de conexiones abiertas.
 */

require('dotenv').config();
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    // En producción real, aquí se añadiría configuración SSL/TLS
    // para cifrar el tráfico entre el servidor web y la BD, ya que
    // viajan por la red interna de la institución:
    // ssl: { rejectUnauthorized: true }
});

// Verificación de conectividad al iniciar (ayuda a depurar problemas
// de red/firewall entre VM1 y VM2 durante la demo).
(async () => {
    try {
        const conn = await pool.getConnection();
        console.log('[DB] Conexión exitosa al servidor de base de datos remoto.');
        conn.release();
    } catch (err) {
        console.error('[DB] No se pudo conectar al servidor de base de datos:', err.message);
        console.error('[DB] Verifica: IP/puerto en .env, reglas de firewall entre VM1 y VM2, y que el usuario MySQL tenga permiso desde esta IP.');
    }
})();

module.exports = pool;
