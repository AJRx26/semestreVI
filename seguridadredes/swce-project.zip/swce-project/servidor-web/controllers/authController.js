/**
 * controllers/authController.js
 *
 * Lógica de autenticación del SWCE.
 *
 * Flujo de login implementado:
 *  1. Validar que llegaron matrícula y contraseña.
 *  2. Buscar al usuario por matrícula en la BD remota.
 *  3. Si no existe -> responder genérico "credenciales inválidas"
 *     (NUNCA decir "el usuario no existe" vs "contraseña incorrecta";
 *     revelar cuál de los dos falló ayuda a un atacante a enumerar
 *     matrículas válidas).
 *  4. Si existe pero está bloqueado temporalmente -> rechazar y
 *     avisar cuánto falta para poder reintentar.
 *  5. Comparar la contraseña recibida contra el hash con bcrypt.compare
 *     (nunca comparar strings directamente).
 *  6. Si falla -> incrementar contador de intentos fallidos; si llega
 *     al máximo, bloquear temporalmente la cuenta.
 *  7. Si es correcta -> resetear contador, regenerar la sesión
 *     (session.regenerate) para prevenir "session fixation", y
 *     guardar solo los datos necesarios del usuario en sesión.
 *  8. Registrar el intento (éxito/fallido/bloqueado) en bitácora.
 */

const bcrypt = require('bcrypt');
const { validationResult } = require('express-validator');
const Usuario = require('../models/Usuario');

const MAX_INTENTOS = parseInt(process.env.MAX_INTENTOS_FALLIDOS || '5', 10);
const MINUTOS_BLOQUEO = parseInt(process.env.MINUTOS_BLOQUEO || '15', 10);

function mostrarLogin(req, res) {
    if (req.session && req.session.usuario) {
        return res.redirect('/dashboard');
    }
    res.render('login', { error: null });
}

async function procesarLogin(req, res) {
    const errores = validationResult(req);
    if (!errores.isEmpty()) {
        return res.status(400).render('login', { error: 'Datos de formulario inválidos.' });
    }

    const { matricula, password } = req.body;
    const ip = req.ip;

    try {
        const usuario = await Usuario.buscarPorMatricula(matricula);

        // Caso 1: usuario no existe. Respuesta genérica.
        if (!usuario) {
            await Usuario.registrarBitacora({
                idUsuario: null,
                matriculaIntento: matricula,
                ip,
                resultado: 'FALLIDO',
            });
            return res.status(401).render('login', { error: 'Matrícula o contraseña incorrectos.' });
        }

        // Caso 2: cuenta inactiva.
        if (!usuario.activo) {
            return res.status(403).render('login', { error: 'Esta cuenta se encuentra deshabilitada.' });
        }

        // Caso 3: cuenta bloqueada temporalmente por intentos fallidos.
        if (usuario.bloqueado_hasta && new Date(usuario.bloqueado_hasta) > new Date()) {
            await Usuario.registrarBitacora({
                idUsuario: usuario.id_usuario,
                matriculaIntento: matricula,
                ip,
                resultado: 'BLOQUEADO',
            });
            return res.status(403).render('login', {
                error: `Cuenta bloqueada temporalmente por múltiples intentos fallidos. Intenta de nuevo después de ${MINUTOS_BLOQUEO} minutos.`,
            });
        }

        // Caso 4: comparar contraseña contra el hash almacenado.
        const passwordValida = await bcrypt.compare(password, usuario.password_hash);

        if (!passwordValida) {
            await Usuario.incrementarIntentosFallidos(usuario.id_usuario);

            const intentosActualizados = usuario.intentos_fallidos + 1;
            if (intentosActualizados >= MAX_INTENTOS) {
                await Usuario.bloquearTemporalmente(usuario.id_usuario, MINUTOS_BLOQUEO);
            }

            await Usuario.registrarBitacora({
                idUsuario: usuario.id_usuario,
                matriculaIntento: matricula,
                ip,
                resultado: 'FALLIDO',
            });

            return res.status(401).render('login', { error: 'Matrícula o contraseña incorrectos.' });
        }

        // Login exitoso: resetear contador de intentos.
        await Usuario.resetearIntentosFallidos(usuario.id_usuario);
        await Usuario.registrarBitacora({
            idUsuario: usuario.id_usuario,
            matriculaIntento: matricula,
            ip,
            resultado: 'EXITO',
        });

        // Regenerar la sesión antes de autenticar: previene
        // "session fixation" (un atacante no puede reusar un ID de
        // sesión que haya fijado antes del login).
        req.session.regenerate((err) => {
            if (err) {
                console.error('[AUTH] Error al regenerar sesión:', err);
                return res.status(500).render('login', { error: 'Ocurrió un error interno. Intenta de nuevo.' });
            }

            req.session.usuario = {
                id: usuario.id_usuario,
                matricula: usuario.matricula,
                nombre: usuario.nombre_completo,
                campus: usuario.campus,
                rol: usuario.nombre_rol,
            };

            return res.redirect('/dashboard');
        });
    } catch (err) {
        console.error('[AUTH] Error en procesarLogin:', err);
        return res.status(500).render('login', { error: 'Ocurrió un error interno. Intenta de nuevo más tarde.' });
    }
}

function logout(req, res) {
    req.session.destroy((err) => {
        if (err) {
            console.error('[AUTH] Error al cerrar sesión:', err);
        }
        res.clearCookie('connect.sid');
        res.redirect('/login');
    });
}

module.exports = { mostrarLogin, procesarLogin, logout };
