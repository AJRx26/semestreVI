/**
 * routes/authRoutes.js
 */

const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const { mostrarLogin, procesarLogin, logout } = require('../controllers/authController');
const { loginLimiter } = require('../middlewares/rateLimiter');

const validacionLogin = [
    body('matricula')
        .trim()
        .notEmpty().withMessage('La matrícula es requerida.')
        .isLength({ max: 20 }).withMessage('Matrícula inválida.')
        .escape(),
    body('password')
        .notEmpty().withMessage('La contraseña es requerida.')
        .isLength({ max: 200 }).withMessage('Contraseña inválida.'),
];

router.get('/login', mostrarLogin);
router.post('/login', loginLimiter, validacionLogin, procesarLogin);
router.post('/logout', logout);

module.exports = router;
