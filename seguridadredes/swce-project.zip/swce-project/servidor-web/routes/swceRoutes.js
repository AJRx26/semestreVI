/**
 * routes/swceRoutes.js
 *
 * Rutas funcionales del SWCE. El dashboard requiere sesión activa
 * (middleware requireAuth), demostrando que el "canal seguro +
 * credenciales" exigido por la política se traduce en: HTTPS a
 * nivel de transporte (ver app.js / helmet) y sesión autenticada
 * a nivel de aplicación.
 */

const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middlewares/auth');

router.get('/', (req, res) => {
    res.render('index');
});

router.get('/dashboard', requireAuth, (req, res) => {
    res.render('dashboard', { usuario: req.session.usuario });
});

module.exports = router;
