# SWCE — Sistema Web de Control Escolar

Proyecto Final · Seguridad en Redes de Cómputo · UNIVER

Este paquete contiene la parte de **aplicación web (SWCE)** y su **base de datos**, diseñadas para correr en **dos servidores separados**, cumpliendo la política institucional de que el servidor de base de datos debe estar totalmente aislado.

```
swce-project/
├── servidor-web/      → Va en la VM1 (Servidor Web)
└── servidor-bd/        → Scripts SQL que se ejecutan en la VM2 (Servidor de BD)
```

Esto fue probado de extremo a extremo (login correcto, dashboard, logout, login fallido, bloqueo de cuenta tras intentos fallidos, bitácora de auditoría) en un entorno equivalente antes de entregarlo.

---

## 1. Arquitectura de los 2 servidores

| | VM1 — Servidor Web | VM2 — Servidor de BD |
|---|---|---|
| Software | Node.js + Express | MySQL / MariaDB |
| Expuesto a | Otros campus / Internet (HTTPS) | **Solo** la IP de VM1, puerto 3306 |
| Contiene | Código de la app, vistas, lógica de login | Tablas `usuarios`, `roles`, `bitacora_accesos`, `sessions` |
| Usuario de BD | Se conecta como `swce_app` (NO root) | Define al usuario `swce_app` restringido por IP de origen |

Esta separación es la base para justificar, en tu documentación de arquitectura, el cumplimiento de la política: *"el servidor de base de datos correspondiente debe estar totalmente aislado"*. El aislamiento real se aplica a nivel de red (firewall/reglas en VM2 o en el router/switch entre campus, fuera de este paquete) **y** a nivel de aplicación (el código nunca expone la BD directamente, solo a través de la API web).

---

## 2. Despliegue en VM2 — Servidor de Base de Datos

### 2.1 Instalar MySQL/MariaDB

```bash
sudo apt update
sudo apt install -y mariadb-server
sudo systemctl enable --now mariadb
sudo mysql_secure_installation
```

### 2.2 Editar el script SQL con tu IP real

Abre `servidor-bd/01_schema_swce.sql` y sustituye **todas** las apariciones de:

```
'swce_app'@'192.168.X.X'
```

por la IP real que tendrá VM1 en tu topología (por ejemplo `'swce_app'@'10.0.10.5'`). También cambia la contraseña:

```sql
CREATE USER IF NOT EXISTS 'swce_app'@'10.0.10.5' IDENTIFIED BY 'TU_PASSWORD_SEGURA_REAL';
```

### 2.3 Ejecutar el script

```bash
mysql -u root -p < 01_schema_swce.sql
```

Esto crea la base `swce_db`, las tablas `roles`, `usuarios`, `bitacora_accesos`, y el usuario `swce_app` con privilegios mínimos (sin acceso a `root`, sin poder ver otras bases de datos).

### 2.4 Generar usuarios de prueba (opcional, para tu demo)

Desde **cualquier máquina con Node** (puede ser tu propia laptop, no necesita ser VM2):

```bash
cd servidor-bd
npm install bcrypt
node generar_usuarios_prueba.js > inserts_usuarios.sql
```

Esto imprime sentencias `INSERT` con contraseñas ya hasheadas con bcrypt. Copia ese contenido y ejecútalo en VM2:

```bash
mysql -u root -p swce_db < inserts_usuarios.sql
```

Edita primero el arreglo `usuariosPrueba` dentro de `generar_usuarios_prueba.js` si quieres otras matrículas/contraseñas para tu demostración.

### 2.5 Configurar el firewall de VM2 (aislamiento real)

```bash
# Solo permitir conexiones MySQL desde la IP de VM1
sudo ufw allow from 10.0.10.5 to any port 3306
sudo ufw deny 3306
```

Ajusta `10.0.10.5` a la IP real de tu servidor web. Esto es lo que demuestra, en la práctica, el aislamiento exigido por la política.

### 2.6 Permisos de la tabla `sessions` (paso único tras el primer arranque)

La librería de sesiones (`express-mysql-session`) crea automáticamente la tabla `sessions` la primera vez que arranca la aplicación web. Por eso el script le da privilegio `CREATE` a `swce_app`. **Después de arrancar la app por primera vez** (sección 3.5), regresa a VM2 y ejecuta:

```sql
GRANT SELECT, INSERT, UPDATE, DELETE ON swce_db.sessions TO 'swce_app'@'10.0.10.5';
REVOKE CREATE ON swce_db.* FROM 'swce_app'@'10.0.10.5';
FLUSH PRIVILEGES;
```

Esto deja al usuario de aplicación en el mínimo privilegio posible para operación normal (ya no puede crear ni borrar tablas).

---

## 3. Despliegue en VM1 — Servidor Web

### 3.1 Instalar Node.js

```bash
sudo apt update
sudo apt install -y nodejs npm
node -v   # recomendado v18 o superior
```

### 3.2 Copiar el proyecto e instalar dependencias

```bash
cd servidor-web
npm install
```

### 3.3 Configurar variables de entorno

```bash
cp .env.example .env
nano .env
```

Rellena especialmente:

```
DB_HOST=<IP de VM2>
DB_PASSWORD=<la misma password que pusiste en el script SQL>
SESSION_SECRET=<genera uno con el comando de abajo>
NODE_ENV=production
```

Para generar un `SESSION_SECRET` aleatorio y seguro:

```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

### 3.4 Certificado HTTPS (canal seguro exigido por la política)

Como la política exige que el acceso al SWCE desde Internet sea "a través de un canal seguro", la app está preparada para servir bajo HTTPS cuando `NODE_ENV=production`. Coloca tus certificados en:

```
servidor-web/certs/privkey.pem
servidor-web/certs/fullchain.pem
```

Para tu demo, puedes generar un certificado autofirmado:

```bash
mkdir -p certs
openssl req -x509 -newkey rsa:2048 -keyout certs/privkey.pem -out certs/fullchain.pem -days 365 -nodes \
  -subj "/C=MX/ST=Veracruz/L=Xalapa/O=UNIVER/CN=swce.univer.local"
```

(Un certificado autofirmado mostrará advertencia en el navegador, pero el tráfico sí viaja cifrado — suficiente para fines de demostración académica. En producción real se usaría un certificado de una CA reconocida.)

Si prefieres probar primero sin HTTPS (más simple para validar que todo funciona), deja `NODE_ENV=development` y la app sirve por HTTP normal en el puerto configurado.

### 3.5 Arrancar la aplicación

```bash
npm start
```

Deberías ver:

```
[SWCE] Servidor HTTPS escuchando en el puerto 3000
[DB] Conexión exitosa al servidor de base de datos remoto.
```

Si ves un error de conexión a la BD, revisa: la IP/puerto en `.env`, que el firewall de VM2 permita la IP de VM1, y que el usuario `swce_app` exista con esa IP exacta en MySQL.

### 3.6 Probar el flujo de login

1. Abre `https://<IP-de-VM1>:3000/` (o `http://` si estás en modo desarrollo)
2. Click en "Ir a iniciar sesión"
3. Usa una de las matrículas que generaste en el paso 2.4
4. Deberías llegar al dashboard con los datos del usuario

---

## 4. Decisiones de seguridad (para tu documentación de "Descripción de configuraciones")

- **Contraseñas**: nunca se guardan en texto plano. Se usa `bcrypt` con factor de costo 12, que incluye salado automático por diseño del algoritmo.
- **Inyección SQL**: todas las consultas usan *prepared statements* (placeholders `?`), nunca concatenación de strings.
- **Sesión**: se regenera el ID de sesión justo después de un login exitoso (`session.regenerate`) para prevenir *session fixation*. La cookie de sesión es `httpOnly` (no accesible desde JavaScript del navegador, mitiga robo vía XSS) y `sameSite: strict` (mitiga CSRF).
- **Persistencia de sesión**: se guarda en la misma BD remota (no en memoria del proceso Node), para que sobreviva reinicios del servidor web y soporte balanceo de carga futuro.
- **Fuerza bruta — dos capas**:
  - Por cuenta: tras `MAX_INTENTOS_FALLIDOS` (configurable, default 5) fallos consecutivos, la cuenta se bloquea `MINUTOS_BLOQUEO` minutos, incluso si después se usa la contraseña correcta.
  - Por IP: `express-rate-limit` limita el número de POST a `/login` por dirección IP en una ventana de 15 minutos, mitigando *credential stuffing* contra muchas matrículas distintas.
- **Mensajes de error genéricos**: el login nunca revela si falló por "matrícula no existe" o "contraseña incorrecta" — siempre dice "Matrícula o contraseña incorrectos", para no facilitar enumeración de cuentas válidas a un atacante.
- **Privilegio mínimo en BD**: el usuario `swce_app` solo tiene los permisos estrictamente necesarios sobre las tablas necesarias, y solo puede conectarse desde la IP del servidor web — nunca usa `root`.
- **Cabeceras HTTP de seguridad**: `helmet` agrega automáticamente protecciones como `X-Frame-Options`, `X-Content-Type-Options`, `Strict-Transport-Security`, etc.
- **Auditoría**: cada intento de login (exitoso, fallido o bloqueado) se registra en `bitacora_accesos` con IP de origen y timestamp, útil para detectar patrones de ataque o accesos desde campus/IPs inesperadas.

---

## 5. Próximos pasos sugeridos (fuera de este paquete)

- Configurar el firewall/reglas de red entre campus para que el tráfico hacia VM2 solo pueda originarse desde VM1 (sección 2.5), idealmente con reglas también a nivel de switch/router, no solo `ufw` en el host.
- Si tu topología requiere que el portal Web institucional (servicio aparte, según el documento del proyecto) también sea accesible "desde cualquier lado", ese sería un tercer servicio independiente del SWCE — este paquete cubre específicamente el SWCE.
- Para el servidor de archivos con acceso restringido solo a equipos de responsables técnicos (última IP de cada red), esa es una configuración de red/firewall, no de esta aplicación.
