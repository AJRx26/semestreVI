-- =====================================================================
-- SWCE - Sistema Web de Control Escolar
-- Script de creación de base de datos
-- Este script se ejecuta en el SERVIDOR DE BASE DE DATOS (VM2),
-- el cual está aislado y solo acepta conexiones desde el
-- Servidor Web (VM1) por el puerto 3306, según política de seguridad.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS swce_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE swce_db;

-- ---------------------------------------------------------------------
-- Tabla de roles (para control de acceso basado en roles - RBAC)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS roles (
    id_rol      INT AUTO_INCREMENT PRIMARY KEY,
    nombre_rol  VARCHAR(30) NOT NULL UNIQUE
);

INSERT INTO roles (nombre_rol) VALUES
    ('alumno'),
    ('docente'),
    ('administrador')
ON DUPLICATE KEY UPDATE nombre_rol = nombre_rol;

-- ---------------------------------------------------------------------
-- Tabla de usuarios
-- La contraseña NUNCA se guarda en texto plano: se almacena el hash
-- generado con bcrypt (incluye su propia sal por diseño del algoritmo).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id_usuario      INT AUTO_INCREMENT PRIMARY KEY,
    matricula       VARCHAR(20) NOT NULL UNIQUE,
    nombre_completo VARCHAR(150) NOT NULL,
    correo          VARCHAR(150) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    id_rol          INT NOT NULL DEFAULT 1,
    campus          VARCHAR(50) NOT NULL,
    intentos_fallidos INT NOT NULL DEFAULT 0,
    bloqueado_hasta DATETIME NULL,
    fecha_creacion  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ultimo_acceso   DATETIME NULL,
    activo          BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT fk_usuarios_rol FOREIGN KEY (id_rol) REFERENCES roles(id_rol)
);

-- ---------------------------------------------------------------------
-- Tabla de bitácora de accesos (auditoría de login - buena práctica
-- de seguridad para detectar intentos de fuerza bruta o accesos
-- anómalos desde otros campus)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bitacora_accesos (
    id_log      INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario  INT NULL,
    matricula_intento VARCHAR(20) NULL,
    ip_origen   VARCHAR(45) NOT NULL,
    resultado   ENUM('EXITO', 'FALLIDO', 'BLOQUEADO') NOT NULL,
    fecha_hora  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_bitacora_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);

-- ---------------------------------------------------------------------
-- Usuario de aplicación con privilegios MÍNIMOS.
-- IMPORTANTE: el servidor web NUNCA debe conectarse con 'root'.
-- Este usuario solo puede SELECT/INSERT/UPDATE sobre swce_db,
-- y solo puede conectarse desde la IP del servidor web (VM1).
-- Sustituye '192.168.X.X' por la IP real asignada a VM1 en tu topología.
-- ---------------------------------------------------------------------
CREATE USER IF NOT EXISTS 'swce_app'@'192.168.X.X' IDENTIFIED BY 'CAMBIA_ESTA_PASSWORD_SEGURA';

GRANT SELECT, INSERT, UPDATE ON swce_db.usuarios TO 'swce_app'@'192.168.X.X';
GRANT SELECT, INSERT ON swce_db.bitacora_accesos TO 'swce_app'@'192.168.X.X';
GRANT SELECT ON swce_db.roles TO 'swce_app'@'192.168.X.X';

-- La tabla "sessions" la crea automáticamente express-mysql-session
-- la primera vez que arranca la app, por lo que necesita CREATE
-- a nivel de base de datos temporalmente.
GRANT CREATE ON swce_db.* TO 'swce_app'@'192.168.X.X';

FLUSH PRIVILEGES;

-- =====================================================================
-- PASO 2 (ejecutar DESPUÉS de arrancar la app por primera vez, una vez
-- que la tabla "sessions" ya fue creada automáticamente):
--
--   GRANT SELECT, INSERT, UPDATE, DELETE ON swce_db.sessions TO 'swce_app'@'192.168.X.X';
--   REVOKE CREATE ON swce_db.* FROM 'swce_app'@'192.168.X.X';
--   FLUSH PRIVILEGES;
--
-- Esto deja al usuario de aplicación con el mínimo privilegio posible
-- en operación normal (sin poder crear/borrar tablas).
-- =====================================================================
