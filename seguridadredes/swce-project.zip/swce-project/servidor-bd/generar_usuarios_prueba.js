/**
 * Script auxiliar para generar usuarios de prueba.
 * Se ejecuta UNA VEZ desde una máquina con Node instalado y con
 * conectividad temporal a la BD (o se generan los hashes aquí y se
 * pegan manualmente en un INSERT, según lo que sea más práctico
 * para tu demo).
 *
 * Uso:
 *   node generar_usuarios_prueba.js
 *
 * Esto imprime los INSERT con el hash ya calculado, listos para
 * pegar en el servidor de base de datos (VM2).
 */

const bcrypt = require('bcrypt');

const SALT_ROUNDS = 12; // factor de costo recomendado (10-12) para bcrypt

const usuariosPrueba = [
    { matricula: 'A0001', nombre: 'Ana Pérez López',    correo: 'ana.perez@univer.mx',    password: 'Xalapa#2026!', rol: 1, campus: 'Xalapa' },
    { matricula: 'A0002', nombre: 'Luis Hernández Cruz', correo: 'luis.hernandez@univer.mx', password: 'Veracruz#2026!', rol: 1, campus: 'Veracruz' },
    { matricula: 'D0001', nombre: 'Mtra. Carla Domínguez', correo: 'carla.dominguez@univer.mx', password: 'PozaRica#2026!', rol: 2, campus: 'PozaRica' },
    { matricula: 'ADM01', nombre: 'Admin Sistemas',      correo: 'admin@univer.mx',          password: 'Admin#2026Seguro!', rol: 3, campus: 'Xalapa' },
];

(async () => {
    console.log('-- INSERTS generados automáticamente con hash bcrypt --\n');
    for (const u of usuariosPrueba) {
        const hash = await bcrypt.hash(u.password, SALT_ROUNDS);
        console.log(
            `INSERT INTO usuarios (matricula, nombre_completo, correo, password_hash, id_rol, campus) VALUES ` +
            `('${u.matricula}', '${u.nombre}', '${u.correo}', '${hash}', ${u.rol}, '${u.campus}');`
        );
    }
    console.log('\n-- Recuerda: estas contraseñas en texto plano son solo para tu demo. --');
    console.log('-- En un entorno real, el usuario las define él mismo al registrarse. --');
})();
